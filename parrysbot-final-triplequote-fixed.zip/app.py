from flask import Flask, request, Response
from twilio.twiml.voice_response import VoiceResponse
import openai
import os

app = Flask(__name__)

def wants_transfer(speech):
    keywords = [
        "talk to someone", "real person", "speak with someone",
        "representative", "connect me", "talk to a human", "transfer me"
    ]
    return any(kw in speech.lower() for kw in keywords)

def caller_is_done(speech):
    keywords = ["no", "no thanks", "that's all", "i'm good", "i'm done"]
    return any(kw in speech.lower() for kw in keywords)

@app.route("/voice", methods=["POST"])
def voice():
    speech = request.form.get("SpeechResult", "").strip()
    response = VoiceResponse()

    if not speech:
        gather = response.gather(input='speech', timeout=5, action='/voice', method='POST')
        gather.say("Thanks for calling Parrys in Hamilton. How can I help you today?", voice='Polly.Salli')
        return Response(str(response), mimetype='text/xml')

    if caller_is_done(speech):
        response.say("Okay, have a nice day. Goodbye!", voice='Polly.Salli')
        response.hangup()
        return Response(str(response), mimetype='text/xml')

    if wants_transfer(speech):
        response.say("Okay, transferring you to a team member now.", voice='Polly.Salli')
        response.dial("+13158240002")
        return Response(str(response), mimetype='text/xml')

    response.say("Let me check that for you...", voice='Polly.Salli')
    response.redirect('/followup?speech=' + speech)
    return Response(str(response), mimetype='text/xml')

@app.route("/followup", methods=["POST", "GET"])
def followup():
    speech = request.args.get("speech") or request.form.get("speech")
    response = VoiceResponse()

    openai.api_key = os.environ.get("OPENAI_API_KEY")
    completion = openai.ChatCompletion.create(
        model="gpt-4o",
        max_tokens=80,
        messages=[
            {
                "role": "system",
                "content": """You are a helpful, warm employee at Parrys Hardware in Hamilton, NY.
Keep responses short and clear.

Store hours: Mon–Fri 8 AM–6 PM, Sat 8–5, Sun 9–5
Address: 100 Utica Street, Hamilton, NY
Shipping: UPS Access Point (drop-off with label), FedEx drop-offs with prepaid labels. We create FedEx labels in-store. Pickup is weekdays only.
Dry Cleaning: Out and back every Wednesday morning.
Repairs: We repair screens and single-pane windows, only if the frame is not damaged.
Top rental pricing: Pressure washer $60, Floor sander $66, Tile saw $58, Appliance cart $15, Drywall lift $37
If unsure, suggest speaking to a team member."""
            },
            {"role": "user", "content": speech}
        ]
    )

    reply = completion.choices[0].message["content"]
    response.say(reply, voice='Polly.Salli')
    gather = response.gather(input='speech', timeout=5, action='/voice', method='POST')
    gather.say("Is there anything else I can help you with?", voice='Polly.Salli')
    return Response(str(response), mimetype='text/xml')

from flask import Flask, request, Response
from twilio.twiml.voice_response import VoiceResponse

app = Flask(__name__)

def wants_transfer(speech):
    keywords = [
        "talk to someone", "real person", "speak with someone",
        "representative", "connect me", "talk to a human", "transfer me"
    ]
    return any(kw in speech.lower() for kw in keywords)

def caller_is_done(speech):
    keywords = ["no", "no thanks", "that's all", "i'm good", "i'm done"]
    return any(kw in speech.lower() for kw in keywords)

@app.route("/voice", methods=["POST"])
def voice():
    speech = request.form.get("SpeechResult", "").strip()
    response = VoiceResponse()
    lowered = speech.lower()

    if not speech:
        response.say("Thanks for calling Parrys in Hamilton. How can I help you today?", voice='Polly.Salli')
        return Response(str(response), mimetype='text/xml')

    if caller_is_done(speech):
        response.say("Okay, have a nice day. Goodbye!", voice='Polly.Salli')
        response.hangup()
        return Response(str(response), mimetype='text/xml')

    if wants_transfer(speech):
        response.say("Okay, transferring you to a team member now.", voice='Polly.Salli')
        response.dial("+13158240002")
        return Response(str(response), mimetype='text/xml')

    if "hour" in lowered or "open" in lowered or "time" in lowered:
        response.say("We're open from 8 to 6, Monday through Friday. Saturday 8 to 5, and Sunday 9 to 5.", voice='Polly.Salli')
        response.say("Is there anything else I can help you with?", voice='Polly.Salli')
        return Response(str(response), mimetype='text/xml')

    if "address" in lowered or "location" in lowered or "where are you" in lowered:
        response.say("We're located at 100 Utica Street in Hamilton, New York.", voice='Polly.Salli')
        response.say("Is there anything else I can help you with?", voice='Polly.Salli')
        return Response(str(response), mimetype='text/xml')

    if "pressure washer" in lowered:
        response.say("Yes, we rent pressure washers for 60 dollars per day.", voice='Polly.Salli')
        response.say("Is there anything else I can help you with?", voice='Polly.Salli')
        return Response(str(response), mimetype='text/xml')

    response.say("I'm sorry, I didn't catch that. Please try again or ask to speak with someone.", voice='Polly.Salli')
    return Response(str(response), mimetype='text/xml')
